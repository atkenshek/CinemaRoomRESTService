package cinema.Requests;
import cinema.Entities.Seat;

public class ReturnResponse {

    private final Seat returned_tickets;

    public ReturnResponse(Seat returned_tickets) {
        this.returned_tickets = returned_tickets;
    }

    public Seat getReturned_tickets() {
        return returned_tickets;
    }
}
